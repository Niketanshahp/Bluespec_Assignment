import math
import random
import sys
from array import *

def bluegen():
    
    global next_rule
    global count_value
    logn = int(math.log(n)/math.log(2))
    power = int(n/4)
    num_of_reg = n + power
    
    sys.stdout = open("odd_even_merge.bsv", "w")

    print ("package odd_even_merge;")
    print("import Vector::*;")
    print ('`define inp_size '+ str(n))
    for i in range(0, n):
        print ('`define num'+ str(i + 1) + " " + str(inp_array[i]))

    print(" ")
    print("(* synthesize *)")
    print(" ")

    # print module
    print("module mkodd_even_merge (Empty);")
    print("Vector#(`inp_size,Reg#(Int#(32))) elements <- replicateM (mkReg(0));")
    print("Vector#(`inp_size,Reg#(Int#(32))) final_res <- replicateM (mkReg(0));")
    print("\tReg#(int) flag;")
    
    print("\tflag <- mkReg(0);")
    count_value = count_value + 1

    print(" ")

    
    print("\tfunction Action compare(int l,int r);")
    print("\t\taction")
    print("\t\t\t let temp_left = elements[l];")
    print("\t\t\t let temp_right = elements[r];")
    print("\t\t\tif(temp_right<temp_left)")
    print("\t\t\tbegin")
    print("\t\t\t\telements[l]<=temp_right;")
    print("\t\t\t\tif(l!=r)")
    print("\t\t\t\telements[r]<=temp_left;")
    print("\t\t\tend")
    print("\t\t\telse")
    print("\t\t\tbegin")
    print("\t\t\t\telements[l]<=temp_left;")
    print("\t\t\t\tif(l!=r)")
    print("\t\t\t\telements[r]<=temp_right;")
    print("\t\t\tend")
    print("\t\tendaction")
    print("\tendfunction")
    
    
    print(" ")
    
    print("\tfunction Action swap_odd_even_values(int l,int r);")
    print("\t\taction")
    print("\t\tint temp_result[`inp_size];")
    print("\t\tint j=l;")
    print("\t\tfor(int i=l;i<=r;i=i+2)")
    print("\t\tbegin")
    print("\t\t\ttemp_result[j] = elements[i];")
    print("\t\t\tj=j+1;")
    print("\t\tend")
    print("\t\tfor(int i=l+1;i<=r;i=i+2)")
    print("\t\tbegin")
    print("\t\t\ttemp_result[j] = elements[i];")
    print("\t\t\tj=j+1;")
    print("\t\tend")
    print("\t\tfor(int i=l;i<=r;i=i+1)")
    print("\t\tbegin")
    print("\t\t\telements[i] <= temp_result[i];")
    print("\t\tend")
    print("\t\tendaction")
    print("\tendfunction")

    # print func merge
    print(" ")
    
    print("\tfunction Action merge(int l,int r);")
    print("\t\taction")
    print("\t\tint i=l,j=l+(r-l+1)/2,c=l+1;")
    print("\t\tint temparr[`inp_size];")
    print("\t\ttemparr[l] = elements[l];")
    print("\t\ttemparr[r] = elements[r];")
    print("\t\ti=i+1;")
    print("\t\tfor(int k=0;k<((r-l+1)/2 - 1);k=k+1)")
    print("\t\tbegin")
    print("\t\t\tif(elements[i] < elements[j])")
    print("\t\t\tbegin")
    print("\t\t\t\ttemparr[c] = elements[i];")
    print("\t\t\t\tc=c+1;")
    print("\t\t\t\ttemparr[c] = elements[j];")
    print("\t\t\t\tc=c+1;")
    print("\t\t\tend")
    print("\t\t\telse if(elements[i] > elements[j])")
    print("\t\t\tbegin")
    print("\t\t\t\ttemparr[c] = elements[j];")
    print("\t\t\t\tc=c+1;")
    print("\t\t\t\ttemparr[c] = elements[i];")
    print("\t\t\t\tc=c+1;")
    print("\t\t\tend")
    print("\t\t\ti=i+1;")
    print("\t\t\tj=j+1;")
    print("\t\tend")
    print("\t\tfor(int z=l;z<=r;z=z+1)")
    print("\t\tbegin")
    print("\t\t\telements[z] <= temparr[z];")
    print("\t\tend")
    print("\t\tendaction")
    print("\tendfunction")


    # print rule operation
    print(" ")

    print("\trule operation(flag == 0);")

    for i in range(0,n):
        print("\t\telements["+str(i)+"] <= `num"+str(i+1)+";")
    next_rule = next_rule+1
    num = next_rule
    #next_rule = next_rule+1
    print('\t\tflag <='+str(num)+ ';')
    
    print("\tendrule")

    print(" ")
    
def print_fun1():
    global next_rule 
    num = next_rule
    print('\n\trule print_fun1'+str(num)+'(flag ==' +str(num)+');')
    print("\t$display(\"Unsorted Array:\");")
    print("\tfor(Integer i=0;i<`inp_size;i=i+1)")
    print("\t\t$display(\"%d\",elements[i]);")
    next_rule = next_rule+1
    num = next_rule
    print('\tflag <='+str(num)+ ';')
    print("\tendrule")

def compare_swap(l,r):
    global next_rule
    num = next_rule
    print('\n\trule cp'+str(num)+'(flag ==' +str(num)+');')
    print("\t\tint lft;")
    print("\t\tint rht;")
    print('\t\tlft = '+str(int(l))+';')
    print('\t\trht = '+str(int(r))+';')
    print("\t\tcompare(lft,rht);")
    next_rule = next_rule+1
    num = next_rule
    print('\t\tflag <='+str(num)+ ';')
    print("\tendrule")

    print(" ")
    
def Swap_odd_even_values(l,r):
    global next_rule 
    num = next_rule
    print('\n\trule oesw'+str(num)+'(flag ==' +str(num)+');')
    print("\t\tint lft;")
    print("\t\tint rht;")
    print('\t\tlft = '+str(int(l))+';')
    print('\t\trht = '+str(int(r))+';')
    print("\t\tswap_odd_even_values(lft,rht);")
    next_rule = next_rule+1
    num = next_rule
    print('\t\tflag <='+str(num)+ ';')
    print("\tendrule")

    print(" ")
    
def Odd_Even_merge(l,r):
    global next_rule 
    num = next_rule
    print('\n\trule oemr'+str(num)+'(flag ==' +str(num)+');')
    print("\t\tint lft;")
    print("\t\tint rht;")
    print('\t\tlft = '+str(int(l))+';')
    print('\t\trht = '+str(int(r))+';')
    print("\t\tmerge(lft,rht);")
    next_rule = next_rule+1
    num = next_rule
    print('\t\tflag <='+str(num)+ ';')
    print("\tendrule")


def Merge(inp_array,l,r):
    len = sys.getsizeof(inp_array)
    if r-l == 1:
        compare_swap(l,r)
    else:
        if l < r: 
            m = (l+(r-1))/2
            
            Swap_odd_even_values(l,r)
            Merge(inp_array,l,m)
            Merge(inp_array,m+1,r)
            Odd_Even_merge(l,r)
    
    

def mergeSort(inp_array,l,r): 
    len = sys.getsizeof(inp_array)
    if r-l == 1:
        compare_swap(l,r)
    else:
        m = (l+(r-1))/2
        mergeSort(inp_array, l, m) 
        mergeSort(inp_array, m+1, r) 
        Merge(inp_array,l,r)

def print_fun2():
    global next_rule 
    num = next_rule
    print('\n\trule print_fun2'+str(num)+'(flag ==' +str(num)+');')
    print("\t$display(\"Sorted Array:\");")
    print("\tfor(Integer i=0;i<`inp_size;i=i+1)")
    print("\t\t$display(\"%d\",elements[i]);")
    next_rule = next_rule+1
    num = next_rule
    print('\tflag <='+str(num)+ ';')
    print("\t$finish(0);")
    print("\tendrule")
        
print(" ")
print("MAIN")
inp_array = []
next_rule = 0
count_value=0
n = int(input("Number of values: "))
for i in range (0,n):
    m = random.randint(-1000,1000)
    inp_array.append(int(m))
bluegen()
print_fun1()
mergeSort(inp_array,0,n-1) 
print_fun2()
print(" ")
print("endmodule")
print("endpackage")
